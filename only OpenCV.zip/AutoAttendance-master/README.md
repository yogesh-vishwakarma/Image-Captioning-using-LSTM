# AutoAttendance
Taking attendence by face recognition using OpenCV libraries

This project is now being done on another repository https://github.com/Abhishek-dev2/OpenCV-Face-Recognition. We shifted to linux because it is more flexible and more libraries were available for linux including OpenFace. We probably will delete this repository but for now, let it be.
